﻿namespace AutomobileLibrary
{
    public class Class1
    {

    }
}
